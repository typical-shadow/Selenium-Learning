package lab8;



import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class SeleniumLab8Junit {
	static WebDriver driver;
	@BeforeClass
	public static void launchWeb() {
		//Step 1
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		
	}
	
	@Test
	public void lab3Test() {
		
		driver.findElement(By.linkText("Desktops")).click();
		driver.findElement(By.linkText("Mac (1)")).click();

		WebElement sortdropdown = driver.findElement(By.id("input-sort"));
		Select s = new Select(sortdropdown);
		s.selectByIndex(1);
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/div/div[2]/div[2]/button[1]")).click();
		
	}

	@Test
	public void lab4Test() {
		
		String title = driver.getTitle();
		assertEquals(title, "Mac");
		driver.findElement(By.linkText("Desktops")).click();
		driver.findElement(By.linkText("Mac (1)")).click();

		String actual = driver.findElement(By.xpath("//*[@id=\"content\"]/h2")).getText();
		
		assertEquals(actual, "Mac");
		WebElement sortdropdown = driver.findElement(By.id("input-sort"));
		Select s = new Select(sortdropdown);
		s.selectByIndex(1);
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/div/div[2]/div[2]/button[1]")).click();
		
		//Step 8
		driver.findElement(By.name("search")).sendKeys("Mobile");
		driver.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();
		//Step 10
		driver.findElement(By.id("input-search")).clear();
		//Step 11
		driver.findElement(By.id("description")).click();
		driver.findElement(By.id("button-search")).click();
		
		
	}
	
}
