package lab10;

import static org.testng.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Lab {





	DesiredCapabilities cap=null;
	WebDriver driver;
	//String browser="chrome";
	@Parameters({"browser"})
	@BeforeClass
	public void Caloriedetails(String browser) throws MalformedURLException
	{
		if(browser.equals("chrome"))
		{
			cap=DesiredCapabilities.chrome();
		//	cap.setBrowserName(browser);
			//cap.setPlatform(Platform.ANY);
			//cap.setVersion("");
		}
		else if(browser.equals("firefox"))
			cap=DesiredCapabilities.firefox();
		else if(browser.equals("ie"))
			cap=DesiredCapabilities.internetExplorer();
		
		driver= new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),cap);
		driver.get("https://demo.opencart.com");
		//driver.close();
		
	
	}
	@Test
	public void Lab3() throws InterruptedException
	{
		
		WebElement e=driver.findElement(By.partialLinkText("Desktops"));		
		System.out.println(e.getText());
		Actions a=new Actions(driver);
		a.moveToElement(e).perform();
		WebElement su=driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[1]/div/div/ul/li[2]/a"));
		a.moveToElement(su).perform();
		su.click();
		WebElement dd=driver.findElement(By.id("input-sort"));
		Select sel=new Select(dd);
		System.out.println("Default value is moderate "+sel.getFirstSelectedOption().getText());
		sel.selectByIndex(1);
		Thread.sleep(2000);
		WebElement b=driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/div/div[2]/div[2]/button[1]"));
		b.click();

		
	}
	
	@Test
	public void Lab4()
	{
		String expectedTitle = "Your Store";
		String actualTitle = driver.getTitle();
		assertEquals(expectedTitle, actualTitle);

		driver.findElement(By.linkText("Desktops")).click();

		String Mac = driver.findElement(By.linkText("Mac (1)")).getAttribute("href");
		driver.navigate().to(Mac);

		WebElement drpdwn = driver.findElement(By.id("input-sort"));
		Select sel = new Select(drpdwn);

		sel.selectByVisibleText("Name (A - Z)");

		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/div/div[2]/div[2]/button[1]")).click();

		WebElement Search = driver.findElement(By.name("search"));
		Search.sendKeys("Mobile");
		driver.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();

		Wait wait = new WebDriverWait(driver, 20);
		Search = driver.findElement(By.name("search"));
		wait.until(ExpectedConditions.visibilityOf(Search));
		Search.clear();

		driver.findElement(By.name("description")).click();
		driver.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();

	}

	

}



