package lab6;

import static org.testng.Assert.assertEquals;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;

public class OpenCartValidate {

	WebDriver driver;
	@BeforeClass
	public void Beforeclass() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\learning\\Desktop\\Sonali\\VnV\\Module 4\\Advanced Selenium Libs\\WebDriver API\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://demo.opencart.com/");
	}
	@Test
	public void Test() throws InterruptedException {
		
		 /******Login********/
		 driver.findElement(By.linkText("My Account")).click();
		 driver.findElement(By.linkText("Login")).click();
		 driver.findElement(By.id("input-email")).sendKeys("sonali@gmail.com");
		 driver.findElement(By.id("input-password")).sendKeys("abc12345");
		 driver.findElement(By.cssSelector("input[type='submit']")).click();
		
		driver.findElement(By.linkText("Components")).click();
		driver.findElement(By.linkText("Monitors (2)")).click();
		
		 WebElement showdropdown = driver.findElement(By.id("input-limit"));
		 Select sel1= new Select(showdropdown);
		 sel1.selectByVisibleText("25");
		 driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
	
		 Thread.sleep(2000);
		 driver.findElement(By.partialLinkText("Specification")).click();
		 
		 String ActualprodName = driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[2]/h1")).getText();
		 String ExpectedprodName = "Apple Cinema 30\"";
		 assertEquals(ActualprodName, ExpectedprodName);
		 System.out.println("Verified details : Valid");
		 String ActualprodPrice = driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[2]/ul[2]/li[2]/h2")).getText();
		 String ExpectedprodPrice = "$90.00";
		 assertEquals(ActualprodPrice,ExpectedprodPrice );
		 System.out.println("Verified details : Valid");
		 
		 /*********Add to wishlist*************/
		 driver.navigate().to("https://demo.opencart.com/index.php?route=product/product&path=25_28&product_id=42");
		 
		 //add to wishlist button
		 driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[2]/div[1]/button[1]")).click();
		 Thread.sleep(2000);
		 String[] str = driver.findElement(By.xpath("//*[@id=\"product-product\"]/div[1]")).getText().split("\\r?\\n");
		 System.out.println(str[0]);
		 String ExpectedaddWishList ="Success: You have added Apple Cinema 30\" to your wish list!";
		 assertEquals(str[0], ExpectedaddWishList);
		 System.out.println("Verified : Wishlist msg Apple 30\" ");
		 
		 /*********search button**********/
		 driver.findElement(By.name("search")).sendKeys("Mobile");
		 driver.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();
		 driver.findElement(By.name("description")).click();
		 driver.findElement(By.id("button-search")).click();
		 
		 /**********HTC touch HD**********/
		 driver.findElement(By.linkText("HTC Touch HD")).click();
		 //Quantity txtBox
		 driver.findElement(By.id("input-quantity")).clear();
		 driver.findElement(By.id("input-quantity")).sendKeys("3");
		 
		 
		 /**********Add to cart Message*****************/
		//Add to cart
		 driver.findElement(By.xpath("//*[@id=\"button-cart\"]")).click();
		 Thread.sleep(2000);
		 String[] str1 = driver.findElement(By.xpath("//*[@id=\"product-product\"]/div[1]")).getText().split("\\r?\\n");
		 Thread.sleep(2000);
		 System.out.println(str1[0]);
		 //String[] str1 = driver.findElement(By.partialLinkText("shopping cart")).getText().split("\\r?\\n");
		 String ExpectedaddWishList1 ="Success: You have added HTC Touch HD to your shopping cart!";
		 assertEquals(str1[0], ExpectedaddWishList1);
		 System.out.println("Verified : Wishlist msg for HTC");
		
		 
		 /*************View cart button******************/
		 
		 driver.findElement(By.xpath("//*[@id=\"cart\"]/button")).click();
		 Thread.sleep(200);
		 //driver.findElement(By.partialLinkText("View Cart")).click();
		 driver.findElement(By.cssSelector("a[href='https://demo.opencart.com/index.php?route=checkout/cart']")).click();
		 //verify name added in cart 
		 String actualMobName = driver.findElement(By.linkText("HTC Touch HD")).getText();
		 String expectedMobName = "HTC Touch HD";
		 assertEquals(actualMobName, expectedMobName);
		 
		 //checkout Button
		 driver.findElement(By.linkText("Checkout")).click();
		 
		 //logout
		 driver.findElement(By.linkText("My Account")).click();
		 driver.findElement(By.linkText("Logout")).click();
		 
		 
	}
}
