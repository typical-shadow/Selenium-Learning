package lab5;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class RegisterDemo {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		// FirefoxDriver driver = new FirefoxDriver();
		driver.get("http://demo.opencart.com/");

		String expectedTitle = "Your Store";
		String actualTitle = driver.getTitle();

		if (expectedTitle.equals(actualTitle)) {
			System.out.println("Title Passed.");
		} else {
			System.out.println("Title Failed.");
		}

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();

		String expectedHeading = "Register Account";
		String actualhead = driver.findElement(By.xpath("//*[@id=\"content\"]/h1")).getText();

		if (expectedHeading.equals(actualhead)) {
			System.out.println("Heading Passed.");
		} else {
			System.out.println("Heading Failed.");
		}

		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[2]")).click();

		String expectedWarning = "Warning: You must agree to the Privacy Policy!";
		String actualWarningMessage = driver.findElement(By.xpath("//*[@id=\"account-register\"]/div[1]")).getText();

		System.out.println(actualWarningMessage);
		if (expectedWarning.equals(actualWarningMessage)) {
			System.out.println("Warning Passed.");
		} else {
			System.out.println("Warning Failed.");
		}

		// Part 2

		/**** First Name *****/

		WebElement FirstName = driver.findElement(By.id("input-firstname"));
		FirstName.sendKeys("SonaliRasikaJavedAkanshaChintaman");
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		String expectedfirstnamewarn = "First Name must be between 1 and 32 characters!";
		String actualtxtnamewarn = driver.findElement(By.className("text-danger")).getText();
		assertEquals(actualtxtnamewarn, expectedfirstnamewarn);
		System.out.println("Passed Firstname Warning");

		/**** Last Name *****/

		WebElement LastName = driver.findElement(By.id("input-lastname"));
		LastName.sendKeys("SonaliRasikaJavedAkanshaChintaman");
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		String expectedlastnamewarn = "Last Name must be between 1 and 32 characters!";
		String actuallasttnamewarn = driver.findElement(By.xpath("//*[@id=\"account\"]/div[3]/div/div")).getText();
		assertEquals(actuallasttnamewarn, expectedlastnamewarn);
		System.out.println("Passed Lastname Warning");

		/**** Email *****/

		WebElement email = driver.findElement(By.id("input-email"));
		email.sendKeys("abc@gmail.com");

		/**** Telephone *****/

		WebElement telephone = driver.findElement(By.id("input-telephone"));
		telephone.sendKeys("99867452345");

		// Part3
		/******* Address ***********/
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.name("email")).sendKeys("javed@gmail.com");
		driver.findElement(By.name("password")).sendKeys("javed123456");
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		driver.findElement(By.linkText("Address Book")).click();
		driver.findElement(By.linkText("New Address")).click();

		WebElement add = driver.findElement(By.id("input-address-1"));
		add.sendKeys("Thane");
		
		driver.findElement(By.id("input-city")).sendKeys("Mumbai");
		driver.findElement(By.id("input-postcode")).sendKeys("400078");
		Thread.sleep(2000);
 
		WebElement country_dd = driver.findElement(By.name("country_id"));
		Select country = new Select(country_dd);
		country.selectByVisibleText("India");
		
		Thread.sleep(2000);
		WebElement stateDD = driver.findElement(By.id("input-zone"));
		Select state = new Select(stateDD);
		state.selectByVisibleText("Maharashtra");
		
		//Part4
		driver.findElement(By.xpath("//*[@id=\"column-right\"]/div/a[3]")).click();
		driver.findElement(By.id("input-password")).sendKeys("javed123456");
		driver.findElement(By.id("input-confirm")).sendKeys("javed123456");
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		
		//Part5
		driver.findElement(By.linkText("Newsletter")).click();
		List<WebElement> genderList = driver.findElements(By.name("newsletter"));
		for (WebElement gender : genderList) {
			if (gender.getAttribute("value").equals("1")) {
				if (!gender.isSelected()) {
					gender.click();
					break;
				}
			}
		}
		
		
		
	}

}
