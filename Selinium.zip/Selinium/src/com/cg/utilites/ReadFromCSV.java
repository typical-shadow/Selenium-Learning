package com.cg.utilites;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.Test;

import au.com.bytecode.opencsv.CSVReader;

public class ReadFromCSV {

	@Test
	public void ReadCSV() throws IOException {
		String filename = System.getProperty("user.dir")+"/src/com/cg/testdata/CalorieDataCSV.csv";
		FileReader reader = new FileReader(filename);
		
		CSVReader csvReader = new CSVReader(reader);
		List<String[]> lst = csvReader.readAll();
		Iterator<String[]> itr = lst.iterator();
		
		while(itr.hasNext()) {
			String[] s = itr.next();
			for(int i = 0; i< s.length; i++) {
				System.out.print(s[i]+"\t");
			}
			System.out.println();
		}
	}
	
}
