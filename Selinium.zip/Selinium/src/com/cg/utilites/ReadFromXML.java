package com.cg.utilites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ReadFromXML {

	@Test
	public void readXml() throws DocumentException, FileNotFoundException {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
		String filename = System.getProperty("user.dir")+"/src/com/cg/testdata/CalorieDataXML.xml";
		FileInputStream fileInputStream = new FileInputStream(new File(filename));
		SAXReader reader = new SAXReader();
		Document document = reader.read(fileInputStream);
		String age = document.selectSingleNode("//CalroiesDetails/age").getText();
		WebElement agetTextbox = driver.findElement(By.id("cage"));
		agetTextbox.clear();
		agetTextbox.sendKeys(age);
		
	}
	
}
