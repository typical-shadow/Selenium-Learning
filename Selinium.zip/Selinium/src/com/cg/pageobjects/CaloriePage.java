package com.cg.pageobjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CaloriePage {

	
	@FindBy(id = "cage")
	private WebElement ageElement;
	
	@FindBy(name = "csex")
	private List<WebElement> genderList;
	
	@FindBy(xpath = "//*[@id='cpound']")
	private WebElement weightElement;
	
	@FindBy(how = How.LINK_TEXT, using = "BMI")
	private WebElement BMILink;
	
	private WebDriver driver;
	
	public CaloriePage(ChromeDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void enterCalorieDetails(String age, String sex, String weight) {
		ageElement.clear();
		ageElement.sendKeys(age);
		
		for (WebElement gender : genderList) {
			if (gender.getAttribute("value").equals(sex)) {
				if (!gender.isSelected()) {
					gender.click();
					break;
				}
			}
		}
		
		
		weightElement.clear();
		weightElement.sendKeys(weight);
		
	}
	
	public void ClickBMILink() {
		BMILink.click();
	}
	
	
}
