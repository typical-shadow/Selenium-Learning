package com.cg.pageobjects;


public class BMIPage {

	
	
}
