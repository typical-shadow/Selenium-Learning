package com.cg.testcase;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.pageobjects.CaloriePage;
import com.cg.utilites.ExcelReader;
import com.cg.utilites.PropertyReader;

public class CalorieTestCase {

	ChromeDriver chr;

	@BeforeClass
	public void launchWebsite() throws IOException {
		System.setProperty("webdriver.chrome.driver", "D:\\Javed\\VnV\\chromedriver.exe");
		chr = new ChromeDriver();
		chr.get(PropertyReader.getProperty("appurl"));
	}

	@Test(dataProvider = "getCalories")
	public void EnterCaloriesdetails(Hashtable<String, String> caldata) throws InterruptedException {

		CaloriePage cp = new CaloriePage(chr);
		cp.enterCalorieDetails(caldata.get("age"), caldata.get("sex"), caldata.get("weight"));

	}

	@DataProvider
	public Object[][] getCalories() throws IOException {

		String filename = "CalorieData2.xlsx";
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String sheetname = "calroieTestSheet";
		return ExcelReader.ReadExcelDataObjecttoArr(filepath, filename, sheetname);

	}

}
