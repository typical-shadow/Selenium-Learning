package com.cg.testcase;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.cg.pageobjects.CaloriePage;

public class CaloriePageTest {

}
