package Launch;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocatelyIdName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\Javed\\VnV\\chromedriver.exe");
		ChromeDriver chr = new ChromeDriver();
		chr.get("http:\\www.calculator.net/calorie-calculator.html");
		WebElement ageTextbox = chr.findElement(By.id("cage"));
		ageTextbox.clear();
		ageTextbox.sendKeys("45");

		// Identify list of all elememts by name locator starategy
		// gender - male or female - both can be identified in a list by name attribute
		// we want to select female by default male is selected
		// value = 'f' to identify to female - check if its is not selected, then select
		List<WebElement> genderList = chr.findElements(By.name("csex"));
		for (WebElement gender : genderList) {
			if (gender.getAttribute("value").equals("f")) {
				if (!gender.isSelected()) {
					gender.click();
					break;
				} else {
					System.out.println("Male is checked by default");
				}
			}
		}

	}

}
