package Launch;

import org.openqa.selenium.firefox.FirefoxDriver;

public class FireDemo {

	public static void main(String[] args) {
		FirefoxDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com");

	}

}
