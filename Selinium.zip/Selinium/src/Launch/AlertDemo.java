package Launch;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AlertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\Javed\\VnV\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("D:\\Javed\\VnV\\Module 4\\Lesson 5-HTML Pages\\AlertExample.html");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.name("btnAlert")).click();
		
		
		Alert alt = driver.switchTo().alert();
		System.out.println(alt.getText());
//		alt.accept();
		
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.alertIsPresent());
		alt.dismiss();
		
	}

}
