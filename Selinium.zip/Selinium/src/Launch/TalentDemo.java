package Launch;

public class TalentDemo {

	public static void main(String[] args) {
		
		
		

	}

}
