package Launch;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
		WebElement table = driver.findElement(By.className("cinfoT"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		
		for(WebElement row : rows) {
			
			List<WebElement> cols = row.findElements(By.tagName("td"));
			for(WebElement col : cols) {
				System.out.print(col.getText()+"\t");
			}
			System.out.println();
			
		}
		
		
	}

}
