package Launch;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XPathDemo {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
		
		WebElement ageLabel = driver.findElement(By.xpath("/html/body/div[3]/div[1]/div[5]/table[1]/tbody/tr[1]/td[1]"));
		
		System.out.println(ageLabel.getText());
		
WebElement ageLab = driver.findElement(By.xpath("//*[@id=\'calinputtable\']/tbody/tr[1]/td[1]"));
		
		System.out.println(ageLab.getText());
		//*[@id="calinputtable"]/tbody/tr[1]/td[1]
	}

}
