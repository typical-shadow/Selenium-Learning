package Launch;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		/*id="cactivity"
		 * 
		 * 
		 */
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/calorie-calculator.html");
		
		WebElement dd = driver.findElement(By.id("cactivity"));
		Select s = new Select(dd);
		Thread.sleep(2000);
		System.out.println("Dfault value is Moderator : "+ s.getFirstSelectedOption().getText());
		s.selectByIndex(2);
		Thread.sleep(2000);
		System.out.println("Change the Value to Light Execrise : "+ s.getFirstSelectedOption().getText());
		s.selectByValue("1.725");
		Thread.sleep(2000);
		System.out.println("Change the value to very Active  : "+ s.getFirstSelectedOption().getText());
		s.selectByVisibleText("Extra Active: very intense exercise daily, or physical job");
		System.out.println("Extra Active: very intense exercise daily, or physical job"+ s.getFirstSelectedOption().getText());
		Thread.sleep(2000);
		
		
	}

}
