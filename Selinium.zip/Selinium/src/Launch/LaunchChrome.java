package Launch;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class LaunchChrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*System.setProperty("webdriver.ie.driver","D:\\Javed\\VnV\\Module 4\\Advanced Selenium Libs\\WebDriver API\\IEDriverServer.exe");
		InternetExplorerDriver iedriver = new InternetExplorerDriver();
		iedriver.get("https://www.google.com");*/
		
		
		FirefoxDriver fdriver = new FirefoxDriver();
		fdriver.get("http://www.google.com");
	}

}
