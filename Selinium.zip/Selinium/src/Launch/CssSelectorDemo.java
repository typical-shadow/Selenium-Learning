package Launch;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CssSelectorDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "D:\\Javed\\VnV\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://talent.capgemini.com");
		
		/*
		Css Selectors
		WebElement user = driver.findElement(By.cssSelector("input.TxtFld"));
		user.sendKeys("javedsha");
		Thread.sleep(2000);
		Interogation API
		driver.navigate().to("https://www.google.com");
		*/
		
		//Title Check
		/*String expected = "Calorie Calculator";
		String actual = driver.getTitle();
		System.out.println(actual);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getPageSource());
		if(expected.equals(actual)) {
			System.out.println("Passed");
		}else{
			System.out.println("Failed");
		}*/
		
		WebElement user = driver.findElement(By.cssSelector("input.TxtFld"));
		user.sendKeys("javedsha");
		System.out.println(user.getAttribute("value"));
		
	}

}
